public enum Material {
    PLUSH,
    WOODEN,
    METAL
}
