public enum Color {
    GREY,
    PINK,
    WHITE,
    YELLOW,
    BROWN
}
