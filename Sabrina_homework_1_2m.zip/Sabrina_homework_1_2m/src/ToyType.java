public enum ToyType {
    BEAR,
    DOG,
    CAT
}
